import './MovieArchiveHeader.css';

import React, { useState, useContext } from 'react';
import { StateContext } from '../MovieArchiveApp';

export default function MovieArchiveHeader({ setBodyPage }) {

    const userInfo = useContext(StateContext).userInfoProvider;

    return(
        <div className='header-container'>
            <button onClick={() => setBodyPage("home")} className='home-page-btn'><i class="fa-solid fa-film"></i> Movie Archive</button>
            <input className='search-field'></input>
            <button onClick={() => setBodyPage("home")} className='favorite-page-btn'><i class="fa-regular fa-bookmark"></i>Favorites</button>
            <button onClick={() => setBodyPage("login")} className='login-page-btn'>{userInfo ? "Logged" : "Log In"}</button>
        </div>
    );
}