

export default function MovieArchiveHome({ moviesList }) {

    return(
        <div className="home-container">
            {moviesList.map((movie) => {
                return (<p>{movie.title}</p>)
            })}
        </div>
    );
}