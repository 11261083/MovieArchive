import './MovieArchiveBody.css';
import Home from './Home/MovieArchiveHome.jsx';
import Detail from './Detail/MovieDetail.jsx';
import Login from './Login/MovieArchiveLogin.jsx';
import apiConfig from '../services/tmdbApiConfig.jsx'

import React, { useState, useEffect, useContext } from 'react';
import { StateContext } from '../MovieArchiveApp';

export default function MovieArchiveBody({ bodyPage }) {

    const [moviesList, setMoviesList] = useState([]);
    const [selectedMovieDetail, setSelectedMovieDetail] = useState(null);

    useEffect(() => {
    
        async function fetchData() {
            try {
                let result;
                result = await getRecentMovies();
                setMoviesList(result);
            }
            catch(e) {
                console.error(e);
            }
        }

        if(bodyPage === "home") {
            fetchData();
        }

    }, [bodyPage]);

    function bodyPageRender(page) {
        switch(page) {
            case "home": 
                return <Home moviesList={moviesList}/>;
            case "detail":
                return <Detail />;
            case "login":
                return <Login />;
        }
    }

    return(
        <div className='body-container'>
            { bodyPageRender(bodyPage) }
        </div>
    );
}

async function getRecentMovies() {
    try {
        const response = await apiConfig.get('/discover/movie', {
            params: {
                page: 1,
                sort_by: "revenue.desc",
                with_genres: ""
            }
        });
        
        return response.data.results;
    }
    catch(e) {
        console.error(e);
        return null;
    }
}