

export default function MovieDetail() {

    return(
        <div className="detail-container">
        </div>
    );
}