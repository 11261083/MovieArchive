import './MovieArchiveLogin.css';

import React, { useState, useContext } from 'react';
import { StateContext } from '../../MovieArchiveApp';

export default function MovieArchiveLogin() {

    const userInfo = useContext(StateContext).userInfoProvider;
    const userLogin = useContext(StateContext).userLoginProvider;
    const userLogout = useContext(StateContext).userLogoutProvider;
    const userRegister = useContext(StateContext).userRegisterProvider;
    const userDeleteAccount = useContext(StateContext).userDeleteAccountProvider;

    const [userIdInput, setUserIdInput] = useState('');
    const [userPasswordInput, setUserPasswordInput] = useState('');

    function handleRegisterBtn() {
        const {result, message} = userRegister(userIdInput, userPasswordInput);
        if(!result) alert(message);
        else {
            setUserIdInput('');
            setUserPasswordInput('');
        }
    }

    function handleLoginBtn() {
        const {result, message} = userLogin(userIdInput, userPasswordInput);
        if(!result) alert(message);
        else {
            setUserIdInput('');
            setUserPasswordInput('');
        }
    }

    function handleDeleteAccountBtn() {
        const {message} = userDeleteAccount(userInfo.id);
        alert(message);
    }

    return(
        <div className="login-container">
            {userInfo ? (
                    <div className='login-box'>
                        <p>Account Information</p>
                        <label>Email/ID</label>
                        <input value={userInfo.id} disabled></input>
                        <label>Password</label>
                        <input value={userInfo.password} disabled></input>
                        <div className='login-button-box'>
                            <button onClick={handleDeleteAccountBtn}>Delete Account</button>
                            <button onClick={() => userLogout()}>Log out</button>
                        </div>
                    </div>
                ) : (
                    <div className='login-box'>
                        <p>Log In</p>
                        <label>Enter your Email</label>
                        <input value={userIdInput} onChange={(e) => setUserIdInput(e.target.value)}></input>
                        <label>Password</label>
                        <input value={userPasswordInput} onChange={(e) => setUserPasswordInput(e.target.value)}></input>
                        <div className='login-button-box'>
                            <button onClick={handleRegisterBtn}>Register</button>
                            <button onClick={handleLoginBtn}>Log in</button>
                        </div>
                    </div>
                )
            }
        </div>
    );
}