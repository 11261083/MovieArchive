import './MovieArchiveApp.css';
import Header from './Header/MovieArchiveHeader.jsx';
import Body from './Body/MovieArchiveBody.jsx';
import Footer from './Footer/MovieArchiveFooter.jsx';

import React, { useState, useEffect, createContext } from 'react';
import useUserAuth from './hooks/useUserAuth.jsx';

export const StateContext = createContext();

export default function MovieArchiveApp() {

    const { userInfo, userLogin, userLogout, userRegister, userUpdateFavoriteMoviesList, userDeleteAccount } = useUserAuth();
    const [bodyPage, setBodyPage] = useState("home");

    return(
        <div className='movie-archive-app-container'>
            <div className='movie-archive-app-box'>
                <StateContext.Provider value={
                    {
                        userInfoProvider: userInfo,
                        userLoginProvider: userLogin,
                        userLogoutProvider: userLogout,
                        userRegisterProvider: userRegister,
                        userUpdateFavoriteMoviesListProvider: userUpdateFavoriteMoviesList,
                        userDeleteAccountProvider: userDeleteAccount
                    }
                }>
                    <Header setBodyPage={setBodyPage}/>
                    <Body bodyPage={bodyPage}/>
                    <Footer/>
                </StateContext.Provider>
            </div>
        </div>
    );
}