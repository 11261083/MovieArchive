import './MovieArchiveFooter.css'

export default function MovieArchiveFooter() {

    return(
        <div className="footer-container">
            
        </div>
    );
}