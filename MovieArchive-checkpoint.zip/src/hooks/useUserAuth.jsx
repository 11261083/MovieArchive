import React, { useState, useEffect } from 'react';

export default function useUserAuth() {

    const [user, setUser] = useState(null);

    useEffect(() => {
        if(user) {
            localStorage.setItem(user.id, JSON.stringify(user));
        }
    }, [user]);

    function userLogin(id, pw) {
        const savedUser = JSON.parse(localStorage.getItem(id));
        if(savedUser) {
            if(savedUser.password !== pw) {
                return { result: false, message: "Wrong Password!" };
            }
            else {
                setUser(savedUser);
                return { result: true, message: "Login Successful!" };
            }
        }
        return { result: false, message: "Your ID is not registered!" };
    }

    function userLogout() {
        setUser(null);
    }

    function userRegister(id, pw) {

        if(user) return;
        
        if(localStorage.getItem(id)) return { result: false, message: "Your ID is already registered!" };

        if(id && pw) {
            setUser({id: id, password: pw, favoriteMovieslist: []});
        }
        else {
            return { result: false, message: "Type a valid ID and Password!" };
        }
    }

    function userUpdateFavoriteMoviesList(list) {

        if(!user) return;

        setUser(prev => ({...prev, favoriteMovieslist: list}));
        return { result: true, message: "Update Success!" };
    }

    function userDeleteAccount(id) {
        localStorage.removeItem(id);
        if(!localStorage.getItem(id)) {
            userLogout();
            return { result: true, message: "User Deleted Successfully!" }
        }
        else return {result: false, message: "Failed Deleting User!"}
    }

    return {
        userInfo: user,
        userLogin,
        userLogout,
        userRegister,
        userUpdateFavoriteMoviesList,
        userDeleteAccount
    };
}